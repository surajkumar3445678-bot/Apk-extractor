package com.example.apkextractor

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    data class AppItem(val label: String, val pkg: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "APK Extractor - ऐप पर टैप करो"
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }

        val list = ListView(this)
        list.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1,
            apps.map { "${it.label}\n${it.pkg}" }
        )
        list.setOnItemClickListener { _, _, i, _ -> extract(apps[i]) }
        setContentView(list)
    }

    private fun extract(app: AppItem) {
        Toast.makeText(this, "निकाल रहा हूँ: ${app.label}", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val info = packageManager.getApplicationInfo(app.pkg, 0)
                val paths = listOf(info.sourceDir) + (info.splitSourceDirs?.toList() ?: emptyList())
                for (path in paths) {
                    val src = File(path)
                    val name = if (src.name == "base.apk") "${app.pkg}.apk" else "${app.pkg}-${src.name}"
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                        put(MediaStore.Downloads.RELATIVE_PATH, "Download/APK-Extractor/${app.pkg}")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw Exception("फ़ाइल नहीं बन पाई")
                    contentResolver.openOutputStream(uri)!!.use { out ->
                        src.inputStream().use { it.copyTo(out) }
                    }
                }
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "हो गया! ${paths.size} फ़ाइल: Downloads/APK-Extractor/${app.pkg}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
